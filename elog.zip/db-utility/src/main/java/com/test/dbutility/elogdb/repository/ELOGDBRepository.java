package com.test.dbutility.elogdb.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.test.dbutility.elogdb.model.CWDUSERProperties;

 
public interface ELOGDBRepository extends CrudRepository<CWDUSERProperties, Long>{
	
	@Query(value = "select user_name from cwd_user where active='1' and directory_id='10000' order by user_name ASC", nativeQuery = true)
	List<String> getDMPStudy();
	
	@Query(value = "SELECT 	b.pname,b.lead,c.email_Address,count(a.id) FROM JIRAISSUE a,project b,Cwd_User c WHERE a.project=b.id and b.lead=c.user_name and b.pname in :pnames GROUP BY b.pname, b.lead, c.email_Address", nativeQuery = true)
	List<Object[]> getDMPDetails(@Param(value = "pnames") List<String> pnames);
	
}
