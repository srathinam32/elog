
package com.test.dbutility.ldapdb.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "STG_LDAP_OU_PEOPLE", schema = "MATRIX_SHARE_RAVERPT_BI")
public class LDAPUserCount {

	
	@Column(name = "LOGIN")
	private String login;

	@Column(name = "STATUS")
	private String status;

}
