package com.test.dbutility.elogdb.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CWD_USER", schema = "ELOG_JIRA")
public class CWDUSERProperties {
	@Id
	@Column(name = "ID")
	private int id;
	
	@Column(name = "USER_NAME")
	private String locked;
	
	
}